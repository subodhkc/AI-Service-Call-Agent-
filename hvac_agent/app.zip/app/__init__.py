# HVAC Voice Agent - Main Application Package
# Marks app as a package

__version__ = "1.0.0"
