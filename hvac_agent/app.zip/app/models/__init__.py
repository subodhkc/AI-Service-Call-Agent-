# Expose ORM models
from .db_models import Base, Location, Appointment, EmergencyLog, CallLog  # noqa: F401
